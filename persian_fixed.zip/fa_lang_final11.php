﻿<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* language locale */
$lang["language_locale"] = "fa"; //locale code
$lang["language_locale_long"] = "fa_IR"; //long locale code

/* common */
$lang["add"] = "اضافه کردن";
$lang["edit"] = "ویرایش";
$lang["close"] = "بستن";
$lang["cancel"] = "لغو";
$lang["save"] = "ذخیره";
$lang["delete"] = "حذف کردن";
$lang["description"] = "شرح";
$lang["admin"] = "ادمین";
$lang["manager"] = "مدیر";
$lang["options"] = "تنظیمات";
$lang["id"] = "شناسه";
$lang["name"] = "نام";
$lang["email"] = "ایمیل";
$lang["username"] = "نام کاربری";
$lang["password"] = "رمز ورود";
$lang["retype_password"] = "تکرار دوباره";
$lang["previous"] = "قبلی";
$lang["next"] = "بعدی";
$lang["active"] = "فعال کردن";
$lang["inactive"] = "غیر فعال کردن";
$lang["status"] = "وضعیت";
$lang["start_date"] = "تاریخ شروع";
$lang["end_date"] = "تاریخ پایان";
$lang["start_time"] = "تاریخ شروع";
$lang["end_time"] = "تاریخ پایان";
$lang["deadline"] = "تاریخ سر رسید";
$lang["added"] = "اضافه شد";
$lang["created_date"] = "تاریخ ساخت";
$lang["created"] = "ساخت";
$lang["created_by"] = "ساخته شده توسط";
$lang["updated"] = "به روز رسانی";
$lang["deleted"] = "حذف شده";
$lang["currency"] = "واحد پول";
$lang["new"] = "جدید";
$lang["open"] = "بازکردن";
$lang["closed"] = "بستن";
$lang["date"] = "روز";
$lang["yes"] = "بله";
$lang["no"] = "نه";
$lang["add_more"] = "اضافه کردن بیشتر";
$lang["crop"] = "محصول";
$lang["income"] = "درآمد";
$lang["income_vs_expenses"] = "درآمد در مقابل هزینه";

$lang["title"] = "عنوان";
$lang["reset"] = "بازنشانی";
$lang["share_with"] = "اشتراک گذاشتن با";
$lang["company_name"] = "نام شرکت";
$lang["address"] = "آدرس";
$lang["city"] = "شهر";
$lang["state"] = "استان";
$lang["zip"] = "کد پستی";
$lang["country"] = "کشور";
$lang["phone"] = "شماره تماس";
$lang["private"] = "خصوصی";
$lang["website"] = "وب سایت";

$lang["sunday"] = "یکشنبه";
$lang["monday"] = "دوشنبه";
$lang["tuesday"] = "سه شنبه";
$lang["wednesday"] = "چهارشنبه";
$lang["thursday"] = "پنجشنبه";
$lang["friday"] = "جمعه";
$lang["saturday"] = "شنبه";

$lang["daily"] = "روزانه";
$lang["monthly"] = "ماهانه";
$lang["weekly"] = "هفتگی";
$lang["yearly"] = "سالانه";

$lang["see_all"] = "دیدن همه";

/* messages */
$lang["error_occurred"] = "با عرض پوزش در هنگام پردازش مشکلی رخ داده است <br> لطفا بعدا امتحان کنید";
$lang["field_required"] = "این قسمت الزامی است";
$lang["end_date_must_be_equal_or_greater_than_start_date"] = "تاریخ پایان باید برابر یا دیرتر از روز شروع باشد";
$lang["date_must_be_equal_or_greater_than_today"] = "تاریخ باید برابر یا دیرتر از امروز باشد";
$lang["enter_valid_email"] = "لطفا یک آدرس ایمیل معتبر وارد کنید";
$lang["enter_same_value"] = "لطفا همان مقدار را مجدادا وارد کنید";
$lang["record_saved"] = "رکورد ذخیره شد";
$lang["record_updated"] = "رکورد بروزرسانی شد";
$lang["record_cannot_be_deleted"] = "رکورد در حال استفاده است، شما نمی توانید آن را حذف کنید";
$lang["record_deleted"] = "رکورد حذف شد";
$lang["record_undone"] = "رکورد لغو شد";
$lang["settings_updated"] = "تنظیمات بروزرسانی شد";
$lang["enter_minimum_6_characters"] = "لطفا حداقل 6 کارکتر وارد کنید";
$lang["message_sent"] = "پیام ارسال شد";
$lang["invalid_file_type"] = "فرمت فایل مجاز نیست";
$lang["something_went_wrong"] = "یه مشکلی پیش اومده";
$lang["duplicate_email"] = "این ایمیل از قبل ثبت شده است";
$lang["comment_submited"] = "نظر ارسال شد";
$lang["no_new_messages"] = "شما پیغام جدیدی ندارید";
$lang["sent_you_a_message"] = "برای شما پیامی ارسال کرد";
$lang["max_file_size_3mb_message"] = "اندازه فایل نباید بیشتر از 3 مگابایت باشد";
$lang["keep_it_blank_to_use_default"] = "برای استفاده از حالت پیش فرض این مقدار را خالی نگه دارید";
$lang["admin_user_has_all_power"] = "ادمین اختیار کامل دارد";
$lang["no_posts_to_show"] = "هیچ پستی برای نمایش وجود ندارد";

/* team_member */
$lang["add_team_member"] = "اضافه کردن عضو";
$lang["edit_team_member"] = "ویرایش عضو گروه";
$lang["delete_team_member"] = "حذف عضو گروه";
$lang["team_member"] = "عضو گروه";
$lang["team_members"] = "اعضای گروه";
$lang["active_members"] = "اعضای فعال";
$lang["inactive_members"] = "اعضای غیرفعال";
$lang["first_name"] = "نام";
$lang["last_name"] = "نام خانوادگی";
$lang["mailing_address"] = "آدرس پستی";
$lang["alternative_address"] = "آدرس جایگزین";
$lang["phone"] = "شماره تماس";
$lang["alternative_phone"] = "شماره تماس جایگزین";
$lang["gender"] = "جنسیت";
$lang["male"] = "مذکر";
$lang["female"] = "مونت";
$lang["date_of_birth"] = "تاریخ تولد";
$lang["date_of_hire"] = "تاریخ استخدام";
$lang["ssn"] = "کد ملی";
$lang["salary"] = "حقوق";
$lang["salary_term"] = "شرایط حقوقی";
$lang["job_info"] = "اطلاعات شغلی";
$lang["job_title"] = "عنوان شغلی ";
$lang["general_info"] = "اطلاعات عمومی";
$lang["account_settings"] = "تنظیمات حساب";
$lang["list_view"] = "مشاهده لیست";
$lang["profile_image_changed"] = "تصویر پروفایل تغییر کرد";
$lang["send_invitation"] = "ارسال دعوتنامه";
$lang["invitation_sent"] = "دعوت نامه ارسال شد";
$lang["reset_info_send"] = "ایمیل ارسال شد!<br />لطفا ایمیل خود را برای راهنمایی بررسی کنید";
$lang["profile"] = "پروفایل";
$lang["my_profile"] = "پروفایل من";
$lang["change_password"] = "عوض کردن رمز ورود";
$lang["social_links"] = "پیوند های اجتماعی";
$lang["view_details"] = "مشاهده جزئیات";
$lang["invite_someone_to_join_as_a_team_member"] = "دعوت از کسی برای ملحق شدن به گروه";

/* team */
$lang["add_team"] = "افزودن گروه";
$lang["edit_team"] = "ویرایش گروه";
$lang["delete_teamn"] = "حذف گروه";
$lang["team"] = "گروه";
$lang["select_a_team"] = "انتخاب گروه";

/* dashboard */
$lang["dashboard"] = "داشبورد";

/* attendance */
$lang["add_attendance"] = "افزودن حضار";
$lang["edit_attendance"] = "ویرایش حضار";
$lang["delete_attendance"] = "حذف حضار";
$lang["attendance"] = "حضار";
$lang["clock_in"] = "ساعت ورود";
$lang["clock_out"] = "ساعت خروج";
$lang["in_date"] = "تاریخ ورود";
$lang["out_date"] = "تاریخ خروج";
$lang["in_time"] = "زمان ورود";
$lang["out_time"] = "زمان خروج";
$lang["clock_started_at"] = "شروع از ساعت";
$lang["you_are_currently_clocked_out"] = "شما در حال حاضر خارج از ساعت کاری هستید";
$lang["members_clocked_in"] = "ساعت ورود اعضا";
$lang["members_clocked_out"] = "ساعت خروج اعضا";
$lang["my_time_cards"] = "گاهبرگ های من";
$lang["timecard_statistics"] = "آمار گاهبرگ ها";
$lang["total_hours_worked"] = "مجموع ساعات کاری سپری شده";
$lang["total_project_hours"] = "مجموع ساعات پروژه";

/* leave types */
$lang["add_leave_type"] = "افزودن نوع مرخصی";
$lang["edit_leave_type"] = "تغییر نوع مرخصی";
$lang["delete_leave_type"] = "حذف نوع مرخصی";
$lang["leave_type"] = "نوع مرخصی";
$lang["leave_types"] = "انواع مرخصی";

/* leave */
$lang["apply_leave"] = "درخواست مرخصی";
$lang["assign_leave"] = "تعیین مرخصی";
$lang["leaves"] = "مرخصی";
$lang["pending_approval"] = "در انتظار تایید";
$lang["all_applications"] = "همه برنامه ها";
$lang["duration"] = "مدت زمان";
$lang["single_day"] = "یک روزه";
$lang["mulitple_days"] = "چند روزه";
$lang["reason"] = "علت";
$lang["applicant"] = "درخواستت کننده";
$lang["approved"] = "تایید شده";
$lang["approve"] = "تایید";
$lang["rejected"] = "رد شده";
$lang["reject"] = "رد";
$lang["canceled"] = "لغو شده";
$lang["completed"] = "تکمیل شده";
$lang["pending"] = "در انتظار";
$lang["day"] = "روز";
$lang["days"] = "روزها";
$lang["hour"] = "ساعت";
$lang["hours"] = "ساعات";
$lang["application_details"] = "جزئیات برنامه";
$lang["rejected_by"] = "رد شده توسط";
$lang["approved_by"] = "پذیرفته شده توسط";
$lang["start_date_to_end_date_format"] = "%s تا %s";
$lang["my_leave"] = "مرخصی من";

/* events */
$lang["add_event"] = "افزودن رویداد";
$lang["edit_event"] = "ویرایش رویداد";
$lang["delete_event"] = "حذف رویداد";
$lang["events"] = "رویداد ها";
$lang["event_calendar"] = "تقویم رویداد ها";
$lang["location"] = "محل";
$lang["event_details"] = "جزئیات رویداد";
$lang["event_deleted"] = "رویداد حذف شد";
$lang["view_on_calendar"] = "مشاهده در تقویم";
$lang["no_event_found"] = "رویدادی یافت نشد";
$lang["events_today"] = "رویدادهای امروز";

/* announcement */
$lang["add_announcement"] = "افزودن اعلان";
$lang["edit_announcement"] = "ویرایش اعلان";
$lang["delete_announcement"] = "حذف اعلان";
$lang["announcement"] = "اعلان";
$lang["announcements"] = "اعلانات";
$lang["all_team_members"] = "تمامی اعضای گروه";
$lang["all_team_clients"] = "تمامی مشتری های گروه";

/* settings */
$lang["app_settings"] = "تنظیمات برنامه";
$lang["app_title"] = "عنوان برنامه";
$lang["site_logo"] = "لوگوی سایت";
$lang["invoice_logo"] = "لوگوی فاکتور";
$lang["timezone"] = "منطقه زمانی";
$lang["date_format"] = "فرمت تاریخ";
$lang["time_format"] = "فرمت زمان";
$lang["first_day_of_week"] = "اولین روز هفته";
$lang["currency_symbol"] = "نماد ارزی";
$lang["general"] = "عمومی";
$lang["general_settings"] = "تنظیمات عمومی";
$lang["item_purchase_code"] = "کد خرید کالا";
$lang["company"] = "شرکت";
$lang["company_settings"] = "تنظیمات شرکت";
$lang["email_settings"] = "تنظیمات ایمیل";
$lang["payment_methods"] = "روش های پرداخت";
$lang["email_sent_from_address"] = "ارسال ایمیل از آدرس";
$lang["email_sent_from_name"] = "ارسال ایمیل از نام";
$lang["email_use_smtp"] = "استفاده از smtp";
$lang["email_smtp_host"] = "SMTP هاست";
$lang["email_smtp_user"] = "SMTP کاربر";
$lang["email_smtp_password"] = "SMPT رمز عبور";
$lang["email_smtp_port"] = "SMTP پورت";
$lang["send_test_mail_to"] = "ارسال ایمیل تست به";
$lang["test_mail_sent"] = "ایمیل تست ارسال شد";
$lang["test_mail_send_failed"] = "خطا هنگام ارسال ایمیل تست";
$lang["settings"] = "تنظیمات";
$lang["updates"] = "بروزرسانی ها";
$lang["current_version"] = "نسخه فعلی";
$lang["language"] = "زبان";
$lang["ip_restriction"] = "محدودیت IP";
$lang["varification_failed_message"] = "با عرض پوزش کد خرید کالای شما تایید نشد";
$lang["enter_one_ip_per_line"] = "در هر خط یک IP وارد کنید اگر این قمست را خالی بگذارید تمامی کاربران مجاز هستند * کاربران مدیر تحت تاثییر قرار نمیگیرند";
$lang["allow_timecard_access_from_these_ips_only"] = "دسترسی به کارت زمانی را فقط از طریق این IP ها مجاز کنید";
$lang["decimal_separator"] = "جدا کننده اعشار";
$lang["client_settings"] = "تنظیمات کاربر";
$lang["disable_client_login_and_signup"] = "غیرفعال کردن ورود و ثبت نام کاربر";
$lang["disable_client_login_help_message"] = "تا زمانی که این گزینه فعال است کاربران قادر به ورود و ثبت نام در این سیستم نیستند";
$lang["who_can_send_or_receive_message_to_or_from_clients"] = "چه کسی میتواند برای مشتری پیامی بفرستد یا دریافت کند";

/* account */
$lang["authentication_failed"] = "احراز هویت انجام نشد";
$lang["signin"] = "ورود";
$lang["sign_out"] = "خروج";
$lang["you_dont_have_an_account"] = "شما حساب کاربری ندارید";
$lang["already_have_an_account"] = "در حال حاضر حساب کاربری دارید";
$lang["forgot_password"] = "رمز ورود خود را فراموش کرده اید؟";
$lang["signup"] = "ثبت نام";
$lang["input_email_to_reset_password"] = "برای بازنشانی گذرواژه خود ، ایمیل خود را وارد کنید";
$lang["no_acount_found_with_this_email"] = "متأسفیم ، هیچ حسابی با این ایمیل پیدا نشد";
$lang["reset_password"] = "بازنشانی رمز ورود";
$lang["password_reset_successfully"] = "رمز ورود شما با موفقیت تنظیم شد";
$lang["account_created"] = "حساب کاربری شما با موفقیت ایجاد شد";
$lang["invitation_expaired_message"] = "دعوتنامه منقضی شده یا مشکلی پیش آمده است";
$lang["account_already_exists_for_your_mail"] = "این ایمیل قبلا ثبت شده است";
$lang["create_an_account_as_a_new_client"] = "ساخت حساب کاربری به عنوان مشتری جدید";
$lang["create_an_account_as_a_team_member"] = "ساخت حساب کاربری به عنوان عضو گروه";
$lang["create_an_account_as_a_client_contact"] = "ساخت حساب کاربری  به عنوان مخاطب مشتری";

/* messages */
$lang["messages"] = "پیام ها";
$lang["message"] = "پیام";
$lang["compose"] = "ساخت";
$lang["send_message"] = "ارسال پیام";
$lang["write_a_message"] = "نوشتن یک پیام";
$lang["reply_to_sender"] = "پاسخ به ارسال کننده";
$lang["subject"] = "موضوع";
$lang["send"] = "ارسال";
$lang["to"] = "به";
$lang["from"] = "از طرف";
$lang["inbox"] = "صندوق ورودی";
$lang["sent_items"] = "ارسال کالاها";
$lang["me"] = "من";
$lang["select_a_message"] = "انتخاب یک پیام برای مشاهده";

/* clients */
$lang["add_client"] = "افزودن مشتری";
$lang["edit_client"] = "ویرایش مشتری";
$lang["delete_client"] = "حذف مشتری";
$lang["client"] = "مشتری";
$lang["clients"] = "مشتری ها";
$lang["client_details"] = "جزئیات مشتری";
$lang["due"] = "ناشی از";

$lang["add_contact"] = "افزودن مخاطب";
$lang["edit_contact"] = "ویرایش مخاطب";
$lang["delete_contact"] = "حذف مخاطب";
$lang["contact"] = "مخاطب";
$lang["contacts"] = "مخاطبین";
$lang["users"] = "کاربران";
$lang["primary_contact"] = "مخاطب اصلی";
$lang["disable_login"] = "غیرفعال سازی ورود";
$lang["disable_login_help_message"] = "کاربر نمی تواند وارد این سیستم شود";
$lang["email_login_details"] = "ارسال جزئیات ورود به سیستم برای این کاربر";
$lang["generate"] = "تولید";
$lang["show_text"] = "نمایش متن";
$lang["hide_text"] = "مخفی کردن متن";
$lang["mark_as_inactive"] = "علامت گذاری به عنوان غیرفعال";
$lang["mark_as_inactive_help_message"] = "کاربران غیرفعال قادر به ورود به سیستم نیستند و در لیست کاربران فعال شمارش نمی شوند";

$lang["invoice_id"] = "شناسه فاکتور";
$lang["payments"] = "مبلغ پرداختی";
$lang["invoice_sent_message"] = "فاکتور ارسال شد";
$lang["attached"] = "پیوست شده";
$lang["vat_number"] = "مالیات بر ارزش افزوده";
$lang["invite_an_user"] = "دعوت از کاربر برای %s"; // Invite an user for {company name}
$lang["unit_type"] = "نوع واحد";

/* projects */
$lang["add_project"] = "افزودن پروژه";
$lang["edit_project"] = "ویرایش پروژه";
$lang["delete_project"] = "حذف پروژه";
$lang["project"] = "پروژه";
$lang["projects"] = "پروژه ها";
$lang["all_projects"] = "تمامی پروژه ها";
$lang["member"] = "عضو";
$lang["overview"] = "بررسی کلی";
$lang["project_members"] = "اعضای پروژه";
$lang["add_member"] = "افزودن عضو";
$lang["delete_member"] = "حذف عضو";
$lang["start_timer"] = "شروع زمان سنج";
$lang["stop_timer"] = "توقف زمان سنج";
$lang["project_timeline"] = "جدول زمانی پروژه";
$lang["open_projects"] = "پروژه های در حال اجرا";
$lang["projects_completed"] = "پروژه های به پایان رسید";
$lang["progress"] = "پیشرفت";
$lang["activity"] = "فعالیت";
$lang["started_at"] = "شروع شده در";
$lang["customer_feedback"] = "بازخورد مشتری";
$lang["project_comment_reply"] = "پاسح نظر پروژه";
$lang["task_comment_reply"] = "پاسخ نظر کار";
$lang["file_comment_reply"] = "پاسخ نظر فایل";
$lang["customer_feedback_reply"] = "پاسخ بازخورد مشتری";

/* expense */
$lang["add_category"] = "افزودن دسته بندی";
$lang["edit_category"] = "ویرایش دسته بندی";
$lang["delete_category"] = "حذف دسته بندی";
$lang["category"] = "دسته بندی";
$lang["categories"] = "دسته بندی ها";
$lang["expense_categories"] = "دسته بندی های هزینه";
$lang["add_expense"] = "افزودن هزینه";
$lang["edit_expense"] = "ویرایش هزینه";
$lang["delete_expense"] = "حذف هزینه";
$lang["expense"] = "هزینه";
$lang["expenses"] = "هزینه ها";
$lang["date_of_expense"] = "تاریخ هزینه";
$lang["finance"] = "دارایی";

/* notes */
$lang["add_note"] = "افزودن یادداشت";
$lang["edit_note"] = "ویرایش یادداشت";
$lang["delete_note"] = "حذف یادداشت";
$lang["note"] = "یادداشت";
$lang["notes"] = "یادداشت ها";
$lang["sticky_note"] = "یادداشت های شخصی";

/* history */
$lang["history"] = "تاریخچه";

/* timesheet */
$lang["timesheets"] = "جدول های زمانی";
$lang["log_time"] = "زمان ورود به سیستم";
$lang["edit_timelog"] = "ویرایش جدول زمانی";
$lang["delete_timelog"] = "حذف جدول زمانی";
$lang["timesheet_statistics"] = "آمار گاهبرگ ها ";

/* milestones */
$lang["add_milestone"] = "افزودن علامت";
$lang["edit_milestone"] = "ویرایش علامت";
$lang["delete_milestone"] = "حذف علامت";
$lang["milestone"] = "علامت";
$lang["milestones"] = "علامت ها";

/* files */
$lang["add_files"] = "افزودن فایل";
$lang["edit_file"] = "ویرایش فایل";
$lang["delete_file"] = "حذف فایل";
$lang["file"] = "فایل";
$lang["files"] = "فایل ها";
$lang["file_name"] = "نام فایل";
$lang["size"] = "اندازه";
$lang["uploaded_by"] = "آپلود شده توسط";
$lang["accepted_file_format"] = "فرمت فایل پذیرفته شده";
$lang["comma_separated"] = "جدا شده با ویرگول";
$lang["project_file"] = "فایل";
$lang["download"] = "دانلود";
$lang["download_files"] = "دانلود %s فایل"; //Ex. Download 4 files
$lang["file_preview_is_not_available"] = "پیش نمایش فایل در دسترس نیست";

/* tasks */
$lang["add_task"] = "افزودن کار";
$lang["edit_task"] = "ویرایش کار";
$lang["delete_task"] = "حذف کار";
$lang["task"] = "کار";
$lang["tasks"] = "کار ها";
$lang["my_tasks"] = "کار های من";
$lang["my_open_tasks"] = "کار های در حال اجرای من";
$lang["assign_to"] = "اختصاص به";
$lang["assigned_to"] = "اختصاص یافته به";
$lang["labels"] = "پرچسب ها";
$lang["to_do"] = "کارهای روزانه";
$lang["in_progress"] = "در حال پیشرفت";
$lang["done"] = "انجام شده";
$lang["task_info"] = "اطلاعات کار";
$lang["points"] = "امتیازات";
$lang["point"] = "امتیاز";
$lang["task_status"] = "وضعیت کار";

/* comments */
$lang["comment"] = "نظر";
$lang["comments"] = "نظرات";
$lang["write_a_comment"] = "نوشتن نظر";
$lang["write_a_reply"] = "نوشتن پاسخ";
$lang["post_comment"] = "ارسال نظر";
$lang["post_reply"] = "ارسال پاسخ";
$lang["reply"] = "پاسخ";
$lang["replies"] = "پاسخ ها";
$lang["like"] = "like";
$lang["unlike"] = "unlike";
$lang["view"] = "بازدید";
$lang["project_comment"] = "نظر پروژه";
$lang["task_comment"] = "نظر کار";
$lang["file_comment"] = "نظر فایل";

/* time format */
$lang["today"] = "امروز";
$lang["yesterday"] = "دیروز";
$lang["tomorrow"] = "فردا";

$lang["today_at"] = "امروز در";
$lang["yesterday_at"] = "دیروز در";

/* tickets */

$lang["add_ticket"] = "افزودن تیکت";
$lang["ticket"] = "تیکت";
$lang["tickets"] = "تیکت ها";
$lang["ticket_id"] = "شناسه تیکت";
$lang["client_replied"] = "مشتری پاسخ داد";
$lang["change_status"] = "تغییر وضعیت";
$lang["last_activity"] = "آخرین فعالیت";
$lang["open_tickets"] = "تیکت های فعال";
$lang["ticket_status"] = "وضعیت تیکت";

/* ticket types */

$lang["add_ticket_type"] = "افزدون نوع تیکت";
$lang["ticket_type"] = "نوع تیکت";
$lang["ticket_types"] = "انواع تیکت";
$lang["edit_ticket_type"] = "ویرایش نوع تیکت";
$lang["delete_ticket_type"] = "حذف نوع تیکت";

/* payment methods */

$lang["add_payment_method"] = "افزودن روش پرداخت";
$lang["payment_method"] = "روش پرداخت";
$lang["payment_methods"] = "روش های پرداخت";
$lang["edit_payment_method"] = "تغییر روش پرداخت";
$lang["delete_payment_method"] = "حذف روش پرداخت";

/* invoices */

$lang["add_invoice"] = "افزودن فاکتور";
$lang["edit_invoice"] = "ویرایش فاکتور";
$lang["delete_invoice"] = "حذف فاکتور";
$lang["invoice"] = "فاکتور";
$lang["invoices"] = "فاکتور ها";
$lang["bill_date"] = "تاریخ قبض";
$lang["due_date"] = "تاریخ سررسید";
$lang["payment_date"] = "تاریخ پرداخت";
$lang["bill_to"] = "قبض برای";
$lang["invoice_value"] = "ارزش فاکتور";
$lang["payment_received"] = "دریافتی";
$lang["invoice_payments"] = "مبلغ پرداختی";
$lang["draft"] = "پیش نویس";
$lang["fully_paid"] = "تسویه شده";
$lang["partially_paid"] = "پرداخت جزئی";
$lang["not_paid"] = "پرداخت نشده";
$lang["overdue"] = "منقضی شده";
$lang["invoice_items"] = "کالاهای فاکتور";
$lang["edit_invoice"] = "ویرایش فاکتور";
$lang["delete_invoice"] = "حذف فاکتور";
$lang["item"] = "کالا";
$lang["add_item"] = "افزودن کالا";
$lang["create_new_item"] = "ساخت یک کالای جدید";
$lang["select_or_create_new_item"] = "از لیست انتخاب کنید یا کالای جدیدی بسازید";
$lang["quantity"] = "تعداد";
$lang["rate"] = "نرخ";
$lang["total_of_all_pages"] = "کل صفحات";
$lang["sub_total"] = "جمع کل";
$lang["total"] = "مجموع";
$lang["last_email_sent"] = "اخرین ایمیل ارسال شده";
$lang["item_library"] = "مجموعه کالا";
$lang["add_payment"] = "افزودن پرداختی";
$lang["never"] = "هیج وقت";
$lang["email_invoice_to_client"] = "ارسال ایمیل فاکتور برای مشتری";
$lang["download_pdf"] = "دانلود PDF";
$lang["print"] = "پرینت";
$lang["actions"] = "کارها";
$lang["balance_due"] = "بدهی";
$lang["paid"] = "پرداخت شده";
$lang["amount"] = "تعداد";
$lang["invoice_payment_list"] = "لیست پرداخت فاکتور";
$lang["invoice_statistics"] = "آمار فاکتور";
$lang["payment"] = "پرداخت";

/* email templates */
$lang["email_templates"] = "قالب های ایمیل";
$lang["select_a_template"] = "انتخاب قالب";
$lang["avilable_variables"] = "متغیرهای موجود";
$lang["restore_to_default"] = "بازیابی به حالت پیش فرض";
$lang["template_restored"] = "بازگشت قالب به حالت پیش فرض";
$lang["login_info"] = "اطلاعات ورود";
$lang["reset_password"] = "بازنشانی رمز عبور";
$lang["team_member_invitation"] = "دعوت از اعضای گروه";
$lang["client_contact_invitation"] = "دعوت از مخاطب مشتری";
$lang["send_invoice"] = "ارسال فاکتور";
$lang["signature"] = "امضا";

/* roles */

$lang["role"] = "قانون";
$lang["roles"] = "قوانین";
$lang["add_role"] = "افزودن قانون";
$lang["edit_role"] = "ویرایش قانون";
$lang["delete_role"] = "حذف قانون";
$lang["use_seetings_from"] = "استفاده از تنظیمات";
$lang["permissions"] = "مجوز ها";
$lang["yes_all_members"] = "بله، همه اعضا";
$lang["yes_specific_members_or_teams"] = "بله ، اعضا یا گروه های خاص";
$lang["yes_specific_ticket_types"] = "بله ، انواع تیکت های خاص";
$lang["select_a_role"] = "انتخاب یک قانون";
$lang["choose_members_and_or_teams"] = "اعضا و یا گروه ها را انتخاب کنید";
$lang["choose_ticket_types"] = "انتخاب نوع تیکت ها";
$lang["excluding_his_her_time_cards"] = "به استثنای گاه برگ های خودش";
$lang["excluding_his_her_leaves"] = "به استثنای مرخصی های خودش";
$lang["can_manage_team_members_leave"] = "آیا توان مدیریت مرخصی اعضای گروه را دارد؟";
$lang["can_manage_team_members_timecards"] = "آیا توانایی مدیریت گاه برگ اعضای گروه را دارد؟";
$lang["can_access_invoices"] = "آیا می تواند به فاکتورها دسترسی پیدا کند؟";
$lang["can_access_expenses"] = "آیا می تواند به هزینه ها دسترسی پیدا کند؟";
$lang["can_access_clients_information"] = "آیا می تواند به اطلاعات مشتری دسترسی پیدا کند؟";
$lang["can_access_tickets"] = "آیا می تواند به تیکت ها دسترسی پیدا کند؟";
$lang["can_manage_announcements"] = "آیا می تواند اعلامیه ها را مدیریت کند؟";

/* timeline */
$lang["post_placeholder_text"] = "ایده یا اسنادی را به اشتراک بگذارید";
$lang["post"] = "ارسال";
$lang["timeline"] = "گاهشمار";
$lang["load_more"] = "بارگذاری بیشتر";
$lang["upload_file"] = "آپلود فایل";
$lang["upload"] = "آپلود";
$lang["new_posts"] = "مطالب جدید";

/* taxes */

$lang["add_tax"] = "افزودن مالیات";
$lang["tax"] = "مالیات";
$lang["taxes"] = "مالیات";
$lang["edit_tax"] = "ویرایش مالیات";
$lang["delete_tax"] = "حذف مالیات";
$lang["percentage"] = "درصد (%)";
$lang["second_tax"] = "مالیات دوم";

/* Version 1.2 */
$lang["available_on_invoice"] = "موجود در فاکتور";
$lang["available_on_invoice_help_text"] = "روش پرداخت در فاکتور مشتری نمایش داده خواهد شد";
$lang["minimum_payment_amount"] = "حداقل مبلغ پرداختی";
$lang["minimum_payment_amount_help_text"] = "اگر ارزش فاکتور از این مقدار کمتر باشد، مشتری قادر به پرداخت آن از طریق این روش نخواهد بود";
$lang["pay_invoice"] = "پرداخت فاکتور";
$lang["pay_button_text"] = "متن دکمه پرداخت";
$lang["minimum_payment_validation_message"] = "مبلغ پرداخت نمی تواند کمتر از باشد";
$lang["invoice_settings"] = "تنظیمات فاکتور";
$lang["allow_partial_invoice_payment_from_clients"] = "پذیرش پرداخت علی الحساب از مشتری";
$lang["invoice_color"] = "رنگ فاکتور";
$lang["invoice_footer"] = "پاورقی فاکتور";
$lang["invoice_preview"] = "پیش نمایش فاکتور";
$lang["close_preview"] = "بستن پیش نمایش";
$lang["only_me"] = "فقط من";
$lang["specific_members_and_teams"] = "اعضا و گروه های ویژه";
$lang["rows_per_page"] = "تعداد ردیف در هر صفحه";
$lang["price"] = "قیمت";
$lang["security_type"] = "نوع امنیت";

$lang["client_can_view_tasks"] = "آیا مشتری می تواند کارها را مشاهده کند؟";
$lang["client_can_create_tasks"] = "آیا مشتری می تواند کارها را ایجاد کند؟";
$lang["client_can_edit_tasks"] = "آیا مشتری می تواند کارها را ویرایش کند؟";
$lang["client_can_comment_on_tasks"] = "آیا مشتری می تواند در مورد کارها نظر بدهد؟";

$lang["set_project_permissions"] = "تنظیم مجوزهای پروژه";
$lang["can_create_projects"] = "ایجاد پروژه";
$lang["can_edit_projects"] = "ویرایش پروژه";
$lang["can_delete_projects"] = "حذف پروژه";
$lang["can_create_tasks"] = "ایجاد کار";
$lang["can_edit_tasks"] = "ویرایش کار";
$lang["can_delete_tasks"] = "حذف کار";
$lang["can_comment_on_tasks"] = "نظر دادن در مورد کار";
$lang["can_create_milestones"] = "ایجاد علامت";
$lang["can_edit_milestones"] = "ویرایش علامت";
$lang["can_delete_milestones"] = "حذف علامت";
$lang["can_add_remove_project_members"] = "اضافه یا حذف اعضای پروژه";
$lang["can_delete_files"] = "حذف فایل ها";

/* Version 1.2.2 */
$lang["label"] = "علامت گذاری";
$lang["send_bcc_to"] = "ارسال رونوشته محرمانه به هنگام ارسال فاکتور برای مشتری";
$lang["mark_project_as_completed"] = "علامت گذاری پروژه پایان یافته";
$lang["mark_project_as_canceled"] = "علامت گذاری پروژه لغو شده";
$lang["mark_project_as_open"] = "علامت گذاری پروژه درحال انجام";

/* Version 1.3 */
$lang["notification"] = "اعلان";
$lang["notifications"] = "اعلانات";
$lang["notification_settings"] = "تنظیمات اعلان";
$lang["enable_email"] = "فعال کردن ایمیل";
$lang["enable_web"] = "فعال کردن وب";
$lang["event"] = "رویداد";
$lang["notify_to"] = "اطلاع بده";

$lang["project_created"] = "پروژه ایجاد شد";
$lang["project_deleted"] = "پروژه حذف شد";
$lang["project_task_created"] = "کار پروژه ایجاد شد";
$lang["project_task_updated"] = "کار پروژه به روز شد";
$lang["project_task_assigned"] = "کار پروژه تعیین شد";
$lang["project_task_started"] = "کار پروژه شروع شد";
$lang["project_task_finished"] = "کار پروژه به اتمام رسید";
$lang["project_task_reopened"] = "کار پروژه دوباره آغاز شد";
$lang["project_task_deleted"] = "کار پروژه حذف شد";
$lang["project_task_commented"] = "اظهار نظر کار پروژه";
$lang["project_member_added"] = "عضو پروژه اضافه شد";
$lang["project_member_deleted"] = "عضو پروژه حذف شد";
$lang["project_file_added"] = "فایل پروژه اضافه شد";
$lang["project_file_deleted"] = "فایل پروژه حذف شد";
$lang["project_file_commented"] = "نظر فایل پروژه";
$lang["project_comment_added"] = " نظر پروژه اضافه شد";
$lang["project_comment_replied"] = "پاسخ نظر پروژه";
$lang["project_customer_feedback_added"] = "بازخورد مشتری پروژه اضافه شد";
$lang["project_customer_feedback_replied"] = "پاسخ بازخورد مشتری پروژه";
$lang["client_signup"] = "ثبت نام مشتری";
$lang["invoice_online_payment_received"] = "فاکتور پرداخت آنلاین دریافت شد";
$lang["leave_application_submitted"] = "تقاضای مرخصی ارسال شد";
$lang["leave_approved"] = " مرخصی تصویب شد";
$lang["leave_assigned"] = " مرخصی اختصاص داده شد";
$lang["leave_rejected"] = " مرخصی رد شد";
$lang["leave_canceled"] = "مرخصی لغو شد";
$lang["ticket_created"] = "تیکت ساخته شد";
$lang["ticket_commented"] = "نظر تیکت";
$lang["ticket_closed"] = "تیکت بسته شد";
$lang["ticket_reopened"] = "تیکت دوباره آغاز شد";
$lang["leave"] = "مرخصی";

$lang["client_primary_contact"] = "مخاطب اصلی مشتری";
$lang["client_all_contacts"] = "تمامی مخاطبین مشتری";
$lang["task_assignee"] = "نماینده کار";
$lang["task_collaborators"] = "همکاران کار";
$lang["comment_creator"] = "سازنده نظر";
$lang["leave_applicant"] = "ترک متقاضی";
$lang["ticket_creator"] = "سازنده تیکت";

$lang["no_new_notifications"] = "اعلانی یافت نشد";

/* Notification messages */

$lang["notification_project_created"] = "پروژه جدیدی ساخته شد";
$lang["notification_project_deleted"] = "پروژه حذف شد";
$lang["notification_project_task_created"] = "کار جدیدی ساخته شد";
$lang["notification_project_task_updated"] = "کار به روز شد";
$lang["notification_project_task_assigned"] = "کاری به شخص %s محول شد";
$lang["notification_project_task_started"] = "شروع کار جدید";
$lang["notification_project_task_finished"] = "اتمام کار";
$lang["notification_project_task_reopened"] = "کار دوباره آغاز شد";
$lang["notification_project_task_deleted"] = "کار حذف شد";
$lang["notification_project_task_commented"] = "درباره کار نظر داده شد";
$lang["notification_project_member_added"] = "شخص %s به پروژه اضافه شد";
$lang["notification_project_member_deleted"] = "شخص %s از پروژه حذف شد";
$lang["notification_project_file_added"] = "فایل به پروژه اضافه شد";
$lang["notification_project_file_deleted"] = "فایل از پروژه حذف شد";
$lang["notification_project_file_commented"] = "درباره فایل نظر داد";
$lang["notification_project_comment_added"] = "درباره پروژه نظر داد";
$lang["notification_project_comment_replied"] = "به نظر پروژه پاسخ داد";
$lang["notification_project_customer_feedback_added"] = "مشتری درباره پروژه نظر داد";
$lang["notification_project_customer_feedback_replied"] = "مشتری به نظر ارائه شده پاسخ داد";
$lang["notification_client_signup"] = "به عنوان مشتری جدید ثبت نام کرد";
$lang["notification_invoice_online_payment_received"] = " پرداخت آنلاین را دریافت کرد";
$lang["notification_leave_application_submitted"] = "درخواست مرخصی را ثبت کرد";
$lang["notification_leave_approved"] = "درخواست مرخصی شخص %s را تایید کرد";
$lang["notification_leave_assigned"] = "برای شخص %s درخواست مرخصی ثبت کرد";
$lang["notification_leave_rejected"] = "درخواست مرخصی شحص %s را قبول یا رد کرد";
$lang["notification_leave_canceled"] = "درخواست مرخصی را لغو کرد";
$lang["notification_ticket_created"] = "تیکت جدیدی ایجاد کرد";
$lang["notification_ticket_commented"] = "درباره تیکتی نظر داد";
$lang["notification_ticket_closed"] = "تیکت را بست";
$lang["notification_ticket_reopened"] = "تیکت را دوباره آغاز کرد";

$lang["general_notification"] = "اعلان عمومی";

$lang["disable_online_payment"] = "غیرفعال کردن پرداخت آنلاین";
$lang["disable_online_payment_description"] = "پنهان کردن گزینه های پرداخت آنلاین در فاکتور برای این مشتری";

$lang["client_can_view_project_files"] = "مشتری می تواند فایل های پروژه را مشاهده کند؟";
$lang["client_can_add_project_files"] = "مشتری می تواند فایل های پروژه را اضافه کند؟";
$lang["client_can_comment_on_files"] = "مشتری می تواند درباره فایل ها نظر بدهد؟";
$lang["mark_invoice_as_not_paid"] = "علامت گذاری به عنوان پرداخت نشده"; //وضعیت فاکتور را به پرداخت نشده تغییر بده

$lang["set_team_members_permission"] = "تنظیم مجوزهای اعضای گروه";
$lang["can_view_team_members_contact_info"] = "آیا می توان اطلاعات تماس اعضای گروه را مشاهده کرد؟";
$lang["can_view_team_members_social_links"] = "آیا می توان پیوندهای اجتماعی اعضای گروه را مشاهده کرد؟";

$lang["collaborator"] = "همکار";
$lang["collaborators"] = "همکاران";

/* Version 1.4 */

$lang["modules"] = "ماژول ها";
$lang["manage_modules"] = "مدیریت ماژول ها";
$lang["module_settings_instructions"] = "ماژول های مورد استفاده را انتخاب کنید";

$lang["task_point_help_text"] = "نقطه کار به عنوان مقدار کار در نظر گرفته می شود. شما می توانید برای کارهای بسیار دشوار 5 امتیاز و برای کارهای آسان 1 امتیاز تعیین کنید ";

$lang["mark_as_open"] = "علامت گذاری به عنوان باز";
$lang["mark_as_closed"] = "علامت گذاری به عنوان بسته";

$lang["ticket_assignee"] = "واگذار کننده تیکت";

$lang["estimate"] = "برآورد";
$lang["estimates"] = "برآوردها";
$lang["estimate_request"] = "درخواست برآورد";
$lang["estimate_requests"] = "درخواست های برآورد";
$lang["estimate_list"] = "لیست برآورد";
$lang["estimate_forms"] = "برآورد فرم ها";
$lang["estimate_request_forms"] = "فرم های درخواست برآورد";

$lang["add_form"] = "افزودن فرم";
$lang["edit_form"] = "ویرایش فرم";
$lang["delete_form"] = "حذف فرم";

$lang["add_field"] = "افزودن زمینه";
$lang["placeholder"] = "محل نگهدارنده";
$lang["required"] = "الزامی";

$lang["field_type"] = "نوع زمینه";
$lang["preview"] = "پیش نمایش";

$lang["field_type_text"] = "متن";
$lang["field_type_textarea"] = "ناحیه متن";
$lang["field_type_select"] = "انتخاب";
$lang["field_type_multi_select"] = "انتخاب چندگانه";

$lang["request_an_estimate"] = "درخواست برآورد";
$lang["estimate_submission_message"] = "!درخواست شما با موفقیت ثبت شد";

$lang["hold"] = "صبر کنید";
$lang["processing"] = "درحال پردازش";
$lang["estimated"] = "برآورد شد";

$lang["add_estimate"] = "افزودن برآورد";
$lang["edit_estimate"] = "ویرایش برآورد";
$lang["delete_estimate"] = "حذف برآورد";
$lang["valid_until"] = "اعتبار دارد تا";
$lang["estimate_date"] = "تاریخ برآورد";
$lang["accepted"] = "پذیرفته شد";
$lang["declined"] = "!پذیرفته نشد";
$lang["sent"] = "ارسال شد";
$lang["estimate_preview"] = "پیش نمایش برآورد";
$lang["estimate_to"] = "برآورد به";

$lang["can_access_estimates"] = "آیا می توان به برآوردها دسترسی داشت؟";
$lang["request_an_estimate"] = "درخواست برآورد";
$lang["estimate_request_form_selection_title"] = "لطفاً برای ارسال درخواست خود فرمی را از لیست زیر انتخاب کنید";

$lang["mark_as_processing"] = "علامت گذاری به عنوان درحال پردازش";
$lang["mark_as_estimated"] = "علامت گذاری به عنوان برآورد شده";
$lang["mark_as_hold"] = "علامت گذاری به عنوان در انتظار";
$lang["mark_as_canceled"] = "علامت کذاری به عنوان لغو شده";

$lang["mark_as_sent"] = "علامت گذاری به عنوان ارسال شده";
$lang["mark_as_accepted"] = "علامت گذاری به عنوان پذیرفته شده ";
$lang["mark_as_rejected"] = "علامت گذاری به عنوان رد شده";
$lang["mark_as_declined"] = "علامت گذاری به عنوان پذیرفته نشده";

$lang["estimate_request_received"] = "درخواست برآورد دریافت شد";
$lang["estimate_sent"] = "برآورد ارسال شد";
$lang["estimate_accepted"] = "برآورد پذیرفته شد";
$lang["estimate_rejected"] = "برآورد رد شد";

$lang["notification_estimate_request_received"] = "درخواست برآورد دریافت شد";
$lang["notification_estimate_sent"] = "برآوردی را ارسال کرد";
$lang["notification_estimate_accepted"] = "برآوردی را پذیرفت";
$lang["notification_estimate_rejected"] = "برآوردی را رد کرد";

$lang["clone_project"] = "شبیه سازی پروژه";
$lang["copy_tasks"] = "کپی کردن کارها";
$lang["copy_project_members"] = "کپی کردن اعضای پروژه";
$lang["copy_milestones"] = "کپی کردن علامت ها";
$lang["copy_same_assignee_and_collaborators"] = "کپی کردن واگذرکننده و همکاران یکسان";
$lang["copy_tasks_start_date_and_deadline"] = "کپی کردن تاریخ شروع و مهلت کارها";
$lang["task_comments_will_not_be_included"] = "نظرات کارها شامل نمی شوند";
$lang["project_cloned_successfully"] = "پروژه با موفقیت شبیه سازی شد";

$lang["search"] = "جستجو";
$lang["no_record_found"] = "هیچ سابقه ای یافت نشد";
$lang["excel"] = "اکسل";
$lang["print_button_help_text"] = "پس از پایان دکمه esc را بفشارید";
$lang["are_you_sure"] = "آیا اطمینان دارید؟";
$lang["file_upload_instruction"] = "فایل ها را اینجا بکشید و رها کنید" ;
$lang["file_name_too_long"] = "نام فایل بیش از اندازه طولانی است";
$lang["scrollbar"] = "نوار پیمایش";

$lang["short_sunday"] = "یکشنبه";
$lang["short_monday"] = "دوشنبه";
$lang["short_tuesday"] = "سه شنبه";
$lang["short_wednesday"] = "چهارشنبه";
$lang["short_thursday"] = "پنج شنبه";
$lang["short_friday"] = "جمعه";
$lang["short_saturday"] = "شنبه";

$lang["min_sunday"] = "یکشنبه";
$lang["min_monday"] = "دوشنبه";
$lang["min_tuesday"] = "سه شنبه";
$lang["min_wednesday"] = "چهارشنبه";
$lang["min_thursday"] = "پنج شنبه";
$lang["min_friday"] = "جمعه";
$lang["min_saturday"] = "شنبه";

$lang["january"] = "ژانویه";
$lang["february"] = "فوریه";
$lang["march"] = "مارس";
$lang["april"] = "آوریل";
$lang["may"] = "می";
$lang["june"] = "جان";
$lang["july"] = "جولای";
$lang["august"] = "آگوست";
$lang["september"] = "سپتامبر";
$lang["october"] = "اکتبر";
$lang["november"] = "نوامبر";
$lang["december"] = "دسامبر";

$lang["short_january"] = "ژانویه";
$lang["short_february"] = "فوریه";
$lang["short_march"] = "مارس";
$lang["short_april"] = "آوریل";
$lang["short_may"] = "می";
$lang["short_june"] = "جان";
$lang["short_july"] = "جولای";
$lang["short_august"] = "آگوست";
$lang["short_september"] = "سپتامبر";
$lang["short_october"] = "اکتبر";
$lang["short_november"] = "نوامبر";
$lang["short_december"] = "دسامبر";

/* Version 1.5 */

$lang["no_such_file_or_directory_found"] = "چنین فایل و یا مسیری وجود ندارد";
$lang["gantt"] = "گانت";
$lang["not_specified"] = "مشخص نشده";
$lang["group_by"] = "دسته بندی براساس";
$lang["create_invoice"] = "ایحاد فاکتور";
$lang["include_all_items_of_this_estimate"] = "تمامی آیتم های این برآورد را مد نظر قرار بده";
$lang["edit_payment"] = "ویرایش پرداخت";
$lang["disable_client_login"] = "غیرفعال کردن ورود مشتری";
$lang["disable_client_signup"] = "غیرفعال کردن ثبت نام مشتری";

$lang["chart"] = "چارت";
$lang["signin_page_background"] = "پس زمینه صفحه ورود به سیستم";
$lang["show_logo_in_signin_page"] = "نشان دادن لوگو در صفحه ورود به سیستم";
$lang["show_background_image_in_signin_page"] = "نمایش تصویر پس زمینه در صفحه ورود به سیستم";

/* Version 1.6 */

$lang["more"] = "بیشتر";
$lang["custom"] = "سفارشی";
$lang["clear"] = "پاک کردن";
$lang["expired"] = "منقضی شده";
$lang["enable_attachment"] = "فعال کردن پیوست";
$lang["custom_fields"] = "زمینه های سفارشی";
$lang["edit_field"] = "ویرایش زمینه";
$lang["delete_field"] = "حذف زمینه";
$lang["client_info"] = "اطلاعات مشتری";
$lang["edit_expenses_category"] = "ویرایش دسته هزینه ها";
$lang["eelete_expenses_category"] = "حذف دسته هزینه ها";
$lang["empty_starred_projects"] = "برای دسترسی سریع به پروژه های مورد علاقه خود ، لطفاً به نمای پروژه بروید و برروی ستاره کلیک کنید";
$lang["empty_starred_clients"] = "برای دسترسی سریع به مشتری های مورد علاقه خود ، لطفاً به نمای مشتری بروید و برروی ستاره کلیک کنید";
$lang["download_zip_name"] = "فایل ها";
$lang["invoice_prefix"] = "پیشوند فاکتور";
$lang["invoice_style"] = "سبک فاکتور";
$lang["delete_confirmation_message"] = "سآیا اطمینان دارید؟ شما قادر به بازگرداندن این عمل نیستید";
$lang["left"] = "چپ";
$lang["right"] = "راست";
$lang["currency_position"] = "موقعیت ارزی";
$lang["recipient"] = "گیرنده";

$lang["new_message_sent"] = "پیام جدید ارسال شد";
$lang["message_reply_sent"] = "پاسخ پیام";
$lang["notification_new_message_sent"] = "پیامی ارسال کرد";
$lang["notification_message_reply_sent"] = "به پیامی پاسخ داد";
$lang["invoice_payment_confirmation"] = "تأیید پرداخت فاکتور";
$lang["notification_invoice_payment_confirmation"] = "پرداخت دریافت شد";

/* Version 1.7 */

$lang["client_can_create_projects"] = "آیا مشتری اجازه ساخت پروژه را دارد؟";
$lang["client_can_view_timesheet"] = "آیا مشتری می تواند جدول زمانی را مشاهده کند؟";
$lang["client_can_view_gantt"] = "آیا مشتری می تواند چارت گانت را مشاهده کند؟";
$lang["client_can_view_overview"] = "آیا مشتری می تواند نمای کلی پروژه را مشاهده کند؟";
$lang["client_can_view_milestones"] = "آیا مشتری می تواند علامت ها را مشاهده کند؟";

$lang["items"] = "آیتم ها";
$lang["edit_item"] = "ویرایش آیتم";
$lang["item_edit_instruction"] = "توجه: تغییرات روی فاکتورها یا برآوردهای موجود تأثیری نخواهد گذاشت";

$lang["recurring"] = "تکرار";
$lang["repeat_every"] = "هر بار تکرار کنید"; //Ex. repeat every 2 months
$lang["interval_days"] = "روز(ها)";
$lang["interval_weeks"] = "هفته(ها)";
$lang["interval_months"] = "ماه(ها)";
$lang["interval_years"] = "سال(ها)";
$lang["cycles"] = "دوره ها";
$lang["recurring_cycle_instructions"] = "تکرار بعد از تعداد دوره ها متوقف می شود. آن را برای بی نهایت خالی بگذارید";
$lang["next_recurring_date"] = "تاریخ تکرار بعدی";
$lang["stopped"] = "متوقف شد";
$lang["past_recurring_date_error_message_title"] = "تاریخ صورتحساب انتخاب شده و نوع تکرار ، تاریخ گذشته را برمی گرداند";
$lang["past_recurring_date_error_message"] = "تاریخ تکرار بعدی باید در آینده باشد. لطفا تاریخ آینده را وارد کنید";
$lang["sub_invoices"] = "فاکتورهای فرعی";

$lang["cron_job_required"] = "!برای این کار به کرون جاب نیاز است";

$lang["recurring_invoice_created_vai_cron_job"] = "تکرار فاکتور ایجاد شده توسط کرون جاب";
$lang["notification_recurring_invoice_created_vai_cron_job"] = "فاکتور جدید تولید شد";

$lang["field_type_number"] = "عدد";
$lang["show_in_table"] = "نمایش در جدول";
$lang["show_in_invoice"] = "نمایش در فاکتور";
$lang["visible_to_admins_only"] = "فقط برای ادمین ها قابل مشاهده است";
$lang["hide_from_clients"] = "از مشتریان پنهان شود";
$lang["public"] = "همگانی";

$lang["help"] = "راهنمایی";
$lang["articles"] = "مقالات";
$lang["add_article"] = "اضافه کردن مقاله جدید";
$lang["edit_article"] = "ویرایش مفاله";
$lang["delete_article"] = "حذف مقاله";
$lang["can_manage_help_and_knowledge_base"] = "آیا می توان پشتیبانی و پایه دانش را مدیریت کرد؟";

$lang["how_can_we_help"] = "چه کمکی از دستمان بر می آید؟";
$lang["help_page_title"] = "ویکی داخلی";
$lang["search_your_question"] = "سوال خود را جستجو کنید";
$lang["no_result_found"] = "نتیجه ای یافت نشد";
$lang["sort"] = "مرتب سازی";
$lang["total_views"] = "مجموع بازدیدها";

$lang["help_and_support"] = "راهنمایی و پشتیبانی";
$lang["knowledge_base"] = "دانش محور";

$lang["payment_success_message"] = "پرداخت شما تکمیل شده است";
$lang["payment_card_charged_but_system_error_message"] = "ممکن است پول از کارت شما برداشته شده باشد اما ما نمی توانیم روند کار را کامل کنیم. لطفا با مدیر سیستم خود تماس بگیرید";
$lang["card_payment_failed_error_message"] = "اکنون قادر به پردازش پرداخت شما نیستیم. لطفا مجددا تلاش کنید";

$lang["message_received"] = "پیام دریافت شد";
$lang["in_number_of_days"] = "در %s روز"; //Ex. In 7 days
$lang["details"] = "جزئیات";
$lang["summary"] = "خلاصه";
$lang["project_timesheet"] = "جدول زمانی پروژه";

$lang["set_event_permissions"] = "مجوزهای رویداد را تنظیم کنید";
$lang["disable_event_sharing"] = "اشتراک رویداد را غیرفعال کنید";
$lang["can_update_team_members_general_info_and_social_links"] = "آیا می توان اطلاعات عمومی و پیوندهای اجتماعی اعضای گروه را به روز کرد؟";
$lang["can_manage_team_members_project_timesheet"] = "آیا می توان جدول زمانی اعضای گروه را مدیریت کرد؟";

$lang["cron_job"] = "کرون جاب";
$lang["cron_job_link"] = "پیوند کرون جاب";
$lang["last_cron_job_run"] = "آخرین اجرای کرون جاب";
$lang["created_from"] = "ساخته شده از"; //Ex. Created from Invoice#1
$lang["recommended_execution_interval"] = "وقفه اجرای توصیه شده";

/* Version 1.8 */

$lang["integration"] = "ادغام";
$lang["get_your_key_from_here"] = ":کلید خود را از اینجا دریافت کنید";
$lang["re_captcha_site_key"] = "کلید سایت";
$lang["re_captcha_secret_key"] = "کلید رمز";

$lang["re_captcha_error-missing-input-secret"] = "رمز ریکپچا  موجود نیست";
$lang["re_captcha_error-invalid-input-secret"] = "رمز ریکپچا  معتبر نیست";
$lang["re_captcha_error-missing-input-response"] = "لطفا ریکپچا را انتخاب کنید";
$lang["re_captcha_error-invalid-input-response"] = "پارامتر پاسخ نامعتبر یا ناقص است";
$lang["re_captcha_error-bad-request"] = "درخواست نامعتبر یا ناقص است";
$lang["re_captcha_expired"] = "ریکپچا منقضی شده است. لطفا صفحه را دوباره بارگیری کنید";

$lang["yes_all_tickets"] = "بله، تمامی تیکت ها";
$lang["choose_ticket_types"] = "انواع تیکت را انتخاب کنید";

$lang["can_manage_all_projects"] = "می توان همه پروژه ها را مدیریت کرد";
$lang["show_most_recent_ticket_comments_at_the_top"] = "آخرین نظرات مربوط به تیکت را در بالا نشان بده";

$lang["new_event_added_in_calendar"] = "رویداد جدید در تقویم اضافه شد";
$lang["notification_new_event_added_in_calendar"] = "رویداد جدید اضافه شد";

$lang["todo"] = "کار روزانه";
$lang["add_a_todo"] = "...اضافه کردن کار روزانه";

/* Version 1.9 */

$lang["client_groups"] = "گروه های مشتری";
$lang["add_client_group"] = "افزودن گروه مشتری";
$lang["edit_client_group"] = "ویرایش گروه مشتری";
$lang["delete_client_group"] = "حذف گروه مشتری";

$lang["ticket_prefix"] = "پیشوند تیکت";
$lang["add_a_task"] = "افزودن کار";

$lang["add_task_status"] = "افزودن وضعیت کار";
$lang["edit_task_status"] = "ویرایش وضعیت کار";
$lang["delete_task_status"] = "حذف وضعیت کار";

$lang["list"] = "فهرست";
$lang["kanban"] = "کانبان";
$lang["priority"] = "اولویت";
$lang["moved_up"] = "بالا بردن";
$lang["moved_down"] = "پایین آوردن";
$lang["mark_project_as_hold"] = "علامت گذاری پروژه به عنوان در انتظار ";

$lang["repeat"] = "تکرار";

$lang["hide_team_members_list"] = "مخفی کردن فهرست اعضای گروه";

/* Version 2.0 */

$lang["summary_details"] = "خلاصه جزئیات";

$lang["chat"] = "چت";
$lang["my_preferences"] = "شخصی سازی";
$lang["show_push_notification"] = "نشان دادن اطلاع رسانی از طریق اعمال فشار";
$lang["notification_sound_volume"] = "میزان صدای اعلان";

$lang["project_reference_in_tickets"] = "فعال سازی مرجع پروژه";

$lang["hide_menus_from_client_portal"] = "پنهان کردن منوها از پورتال مشتری";
$lang["hidden_menus"] = "منوهای پنهان";

$lang["new_announcement_created"] = "اطلاعیه جدید ایجاد شد";
$lang["notification_new_announcement_created"] = "اطلاعیه جدیدی ساخت";

$lang["month"] = "ماه";
$lang["profit"] = "سود";

$lang["invoice_due_reminder_before_due_date"] = "یادآور سررسید فاکتور قبل از موعد مقرر";
$lang["send_due_invoice_reminder_notification_before"] = "ارسال از طریق یادآور سررسید فاکتور قبل از موعد مقرر";
$lang["send_invoice_overdue_reminder_after"] = "پس از ارسال یادآور تأخیر فاکتور";
$lang["invoice_overdue_reminder"] = "یادآور تاخیر فاکتور";
$lang["recurring_invoice_creation_reminder"] = "تکرار یادآوری ایجاد فاکتور";
$lang["send_recurring_invoice_reminder_before_creation"] = "قبل از ایجاد، یادآور فاکتور تکراری ارسال کنn";

$lang["notification_invoice_due_reminder_before_due_date"] = "یادآوری: سررسید فاکتور";
$lang["notification_invoice_overdue_reminder"] = "یادآوری: فاکتور عقب افتاده است";
$lang["notification_recurring_invoice_creation_reminder"] = "فاکتور به زودی تولید می شود";

$lang["can_delete_leave_application"] = "آیا می توان تقاضای مرخصی را حذف کرد؟";
$lang["no_of_decimals"] = "تعداد اعشار";

$lang["checklist"] = "چک لیست";
$lang["delete_checklist_item"] = "حذف مورد چک لیست";

$lang["save_and_show"] = "ذخیره و نمایش";
$lang["total_leave_yearly"] = "تعداد مرخصی(سالانه)";

$lang["new_conversation"] = "گفتگوی جدید";

$lang["enable_web_notification"] = "فعال کردن اعلان وب";
$lang["enable_email_notification"] = "فعال کردن اعلان ایمیل";

/* Version 2.0.3 */

$lang["show_in_estimate"] = "نشان دادن در برآورد";
$lang["mentioned_members"] = "اعضای مذکور";
$lang["all"] = "همه";

$lang["confirmed"] = "تایید شد";
$lang["confirm"] = "تایید";

$lang["confirmed_by"] = "تایید شده توسط";
$lang["confirm_event"] = "رویداد را تایید کنید";
$lang["reject_event"] = "رویداد را رد کنید";
$lang["event_status"] = "وضعیت رویداد";

$lang["specific_client_contacts"] = "مخاطبین ویژه مشتری";
$lang["choose_client_contacts"] = "مخاطبین مشتری را انتخاب کنید";
$lang["invitations_sent"] = "دعوت نامه ها ارسال شد";

/* Version 2.1 */

$lang["add_new_dashboard"] = "افزودن داشبورد جدید";
$lang["add_row"] = "افزودن ردیف";

$lang["available_widgets"] = "ویجت های موجود";
$lang["your_selected_widgets_will_be_appear_here"] = "ویجت های انتخابی شما در اینجا نشان داده می شوند";
$lang["drag_and_drop_widgets_here"] = "ویجت ها را به اینجا بکشید و رها کنید";
$lang["no_more_widgets_available"] = "ویجت دیگری در دسترس نیست";
$lang["invalid_widget_access"] = "شما اجازه دسترسی به این ویجت را ندارید";

$lang["dashboard_title"] = "عنوان داشبورد";
$lang["edit_dashboard"] = "ویرایش داشبورد";
$lang["edit_title"] = "ویرایش عنوان";
$lang["default_dashboard"] = "داشبورد پیش فرض";

$lang["widget"] = "ویجت";
$lang["widgets"] = "ویجت ها";
$lang["add_widget"] = "افزودن ویجت";
$lang["edit_widget"] = "ویرایش ویجت";
$lang["delete_widget"] = "حذف ویجت";

$lang["content"] = "محتوا";
$lang["clock_in_out"] = "ساعت ورود و خروج";
$lang["custom_widget_details"] = "جزئیات ویجت دلخواه";

$lang["total_projects"] = "کل پروژه ها";
$lang["total_invoices"] = "کل فاکتورها";
$lang["total_payments"] = "کل پرداخت ها";
$lang["total_due"] = "کل بدهی";

$lang["show_title"] = "نمایش عنوان";
$lang["show_border"] = "نمایش حاشیه";

$lang["all_tasks_kanban"] = "همه کارهای کانبان";
$lang["todo_list"] = "فهرست کارهای روزانه";
$lang["open_projects_list"] = "باز کردن لیست پروژه ها";
$lang["starred_projects"] = "پروژه های ستاره دار";
$lang["completed_projects"] = "پروژه های تکمیل شده";

$lang["new_tickets"] = "تیکت های حدید";
$lang["closed_tickets"] = "تیکت های بسته شده";

$lang["clocked_in_team_members"] = "ساعت ورود اعضای گروه";
$lang["clocked_out_team_members"] = "ساعت خروج اعضای گروه";
$lang["latest_online_client_contacts"] = "آخرین مخاطبین آنلاین مشتری";
$lang["latest_online_team_members"] = "آخرین اعضای گروه آنلاین";
$lang["my_tasks_list"] = "فهرست کارهای من";

$lang["discount"] = "تخفیف";
$lang["discount_type"] = "نوع تخفیف";
$lang["edit_discount"] = "ویرایش تخفیف";
$lang["discount_amount"] = "مقدار تخفیف";
$lang["fixed_amount"] = "مقدار ثابت";
$lang["before_tax"] = "قبل از مالیات";
$lang["after_tax"] = "بعد از مالیات";

$lang["access_permission"] = "مجوز دسترسی";
$lang["setup"] = "تنظیمات";
$lang["client_permissions"] = "مجوزهای مشتری";

$lang["invoice_over_payment_error_message"] = "شما نمی توانید بیش از سررسید فاکتور خود پرداخت کنید";
$lang["account_already_exists_for_your_company_name"] = "حساب از قبل برای نام شرکت شما وجود دارد";
$lang["personal_language"] = "زبان شخصی";
$lang["no_messages_text"] = "هنوز هیچ پیامی ندارید";
$lang["no_users_found"] = "هیچ کاریری یافت نشد";

$lang["create_project"] = "ایجاد پروژه";

/* Version 2.2 */

$lang["imap_settings"] = "تنظیمات IMAP";
$lang["enable_email_piping"] = "فعال سازی Email Piping";
$lang["imap_host"] = "هاست IMAP";
$lang["imap_port"] = "پورت";
$lang["imap_ssl_enabled"] = "SSL فعال شد";
$lang["please_upgrade_your_php_version"] = "لطفاً نسخه PHP خود را برای این عملیات ارتقا دهید";
$lang["required_version"] = "نسخه مورد نیاز";
$lang["email_piping_help_message"] = "لطفاً مطمئن شوید که دسترسی IMap شما فعال است";

$lang["enable_rich_text_editor"] = "ویرایشگر متن را در نظرات / توضیحات فعال کنید";

$lang["show_assigned_tasks_only"] = "فقط کارهای تعیین شده را نشان بده";

$lang["batch_update"] = "Batch update";
$lang["cancel_selection"] = "لغو انتخاب";
$lang["select_status"] = "انتخاب وضعیت";

$lang["add_multiple_tasks"] = "افزودن کارهای متعدد";
$lang["save_and_add_more"] = "ذخیره و افزودن موارد بیشتر";
$lang["add_project_time"] = "افزودن زمان پروژه";
$lang["add_to_do"] = "افزودن کار روزانه";
$lang["hide_menus_from_topbar"] = "پنهان کردن منوها از نوار بالا";
$lang["favorite_projects"] = "پروژه های مورد علاقه";
$lang["favorite_clients"] = "مشتری های مورد علاقه";
$lang["dashboard_customization"] = "شخصی سازی داشبورد";
$lang["quick_add"] = "افزودن سریع";

$lang["assign_to_me"] = "به من اختصاص بده";

$lang["favicon"] = "فاویکون";

$lang["enable_google_drive_api_to_upload_file"] = "Google API را برای بارگذاری پرونده فعال کن";
$lang["drive_activation_help_message"] = "از این پس ، همه پرونده ها در Google Drive بارگذاری می شوند";

$lang["mark_all_as_read"] = "علامت گذاری همه به عنوان خوانده شده";
$lang["marked_all_notifications_as_read"] = "علامت گذاری همه اعلان ها به عنوان خوانده شده";

$lang["project_completed"] = "پروژه انجام شد";
$lang["notification_project_completed"] = "پروژه ای را انجام داد";

$lang["google_drive_client_id"] = "شناسه مشتری";
$lang["google_drive_client_secret"] = "رمز عبور مشتری";
$lang["get_your_app_credentials_from_here"] = "گواهی های برنامه خود را از اینجا دریافت کنید:";
$lang["remember_to_add_this_url_in_authorized_redirect_uri"] = "به یاد داشته باشید که این url را در uri redirect uri اضافه کنید";
$lang["save_and_authorize"] = "ذخیره و اجازه دادن";

$lang["preview_next_key"] = "بعدی (کلید پیکان راست)";
$lang["preview_previous_key"] = "قبلی (کلید پیکان چپ)";

$lang["filters"] = "فیلترها";

$lang["authorized"] = "مجاز";
$lang["unauthorized"] = "غیرمجاز";

$lang["not_clocked_id_yet"] = "هنوز ساعت ورود نخورده است";

$lang["create_estimate_request"] = "ایجاد درخواست برآورد";

$lang["in_last_number_of_days"] = "در %s روز اخیر";
$lang["in_last_number_of_month"] = "در %s ماه اخیر";
$lang["in_last_number_of_months"] = " در %s ماه اخیر";

$lang["pusher_app_id"] = "شناسه برنامه";
$lang["pusher_key"] = "کلید";
$lang["pusher_secret"] = "رمز";
$lang["pusher_cluster"] = "دسته";
$lang["enable_push_notification"] = "فعال کردن اعلان فشار";
$lang["push_notification"] = "اعلان فشار";
$lang["disable_push_notification"] = "غیرفعال کردن اعلان فشار";

$lang["unknown_client"] = "مشتری ناشناس";

$lang["income_expenses_widget_help_message"] = "این گزارش فقط درصورتی قابل استفاده است که از ارز واحد استفاده کنید";

$lang["assign_myself_in_this_ticket"] = "خودم را در این تیکت اختصاص بده";

$lang["create_new_task"] = "ایجاد کار جدید";

$lang["default_due_date_after_billing_date"] = "تاریخ موعد مقرر پیش فرض پس از تاریخ صورتحساب";

$lang["field_type_external_link"] = "پیوند خارجی";

$lang["total_days"] = "کل روزها";

$lang["my_timesheet"] = "جدول زمانی من";
$lang["all_timesheets"] = "همه جدول های زمانی";
$lang["my_timesheet_statistics"] = "آمار جدول زمانی من";
$lang["all_timesheets_statistics"] = "آمار همه جدول های زمانی";

$lang["no_field_has_selected"] = "هیچ بخشی انتخاب نشده است";

$lang["imap_help_message_1"] = "شما می توانید ایمیلی تنظیم کنید که هر بار ایمیلی دریافت می کنید، تیکت ها به صورت خودکار ساخته شوند";
$lang["imap_help_message_2"] = "لطفا توجه داشته باشید که سیستم بر اساس ایمیل های خوانده نشده تیکت ایجاد می کند. پس از ایجاد تیکت ، ایمیل ها به عنوان خوانده شده علامت گذاری می شوند. برای دریافت پاسخ در همان تیکت ها ، سیستم شناسه تیکت را در موضوع ایمیل بررسی می کند. اگر شناسه تیکت در موضوع وجود نداشته باشد ، به عنوان تیکت جدید در نظر گرفته می شود. می توانید موضوع ایمیل را از آدرس";
$lang["imap_error_credentials_message"] = "خطا با استفاده از اعتبارنامه نمی توان با imap ارتباط برقرار کرد.";

$lang["client_message_own_contacts"] = "آیا مشتری می تواند به مخاطبین خود پیام ارسال و یا از آن ها پیامی دریافت کند؟";

$lang["print_invoice"] = "چاپ فاکتور";

$lang["mark_invoice_as_cancelled"] = "علامت گذاری به عنوان لغو شده";
$lang["cancelled"] = "لغو شده";
$lang["cancelled_at"] = "لغو شده در ";
$lang["cancelled_by"] = "لغو شده توسط";

/* Version 2.3 */

$lang["test_push_notification"] = "آزمایش اعلان فشار";
$lang["notification_test_push_notification"] = "این آزمایش اعلان دمو می باشد";
$lang["push_notification_error_message"] = "خطا با استفاده از گواهینامه ها نمی توان با Pusher ارتباط برقرار کرد";
$lang["clone_estimate"] = "شبیه سازی برآورد";

$lang["import_clients"] = "وارد کردن مشتری ها";
$lang["download_sample_file"] = "بارگیری نمونه فایل";

$lang["estimate_settings"] = "تنظیمات برآورد";
$lang["estimate_logo"] = "لوگو برآورد";
$lang["estimate_color"] = "رنگ برآورد";
$lang["initial_number_of_the_estimate"] = "شماره اولیه برآورد";
$lang["the_estimates_id_must_be_larger_then_last_estimate_id"] = "شناسه برآورد باید بزرگتر از آخرین شناسه برآورد باشد";

$lang["send_to_client"] = "ارسال برای مشتری";
$lang["estimate_sent_message"] = "برآورد ارسال شد";
$lang["send_estimate_bcc_to"] = "به هنگام ارسال برآورد برای مشتری، رونوشت محرمانه را ارسال کن به:";
        
$lang["task_settings"] = "تنظیمات کار";
$lang["enable_recurring_option_for_tasks"] = "فعال کردن گزینه تکرار برای کارها";
$lang["past_recurring_date_error_message_title_for_tasks"] = "تاریخ شروع و نوع تکرار تاریخ گذشته را بر می گرداند";
$lang["recurring_task_created_via_cron_job"] = "کار تکراری ایجاد شده از طریق کورن جاب";
$lang["notification_recurring_task_created_via_cron_job"] = "کار جدید ایجاد شد";
$lang["repeat_type"] = "نوع تکرار";
$lang["lead_status"] = "وضعیت پیشتاز";
$lang["add_lead_status"] = "افزودن وضعیت پیشتاز";
$lang["edit_lead_status"] = "ویرایش وضعیت پیشتاز";
$lang["delete_lead_status"] = "حذف وضعیت پیشتاز";
$lang["owner"] = "مالک";
$lang["make_client"] = "ساحت مشتری";
$lang["client_contacts"] = "محاطبین مشتری";
$lang["lead_contacts"] = "مخاطبین پیشتاز";
$lang["add_a_lead"] = "افزودن پیشتاز";
$lang["source"] = "منبع";
$lang["lead_source"] = "منبع پیشتاز";
$lang["add_lead_source"] = "افزودن منبع پیشتاز";
$lang["edit_lead_source"] = "ویرایش منبع پیشتاز";
$lang["delete_lead_source"] = "حذف منبع پیشتاز";
$lang["custom_field_migration"] = "جابه جایی زمینه سفارشی";
$lang["merge_custom_fields"] = "ادغام زمینه های سفارشی";
$lang["do_not_merge"] = "ادغام نکن";
$lang["merge_custom_fields_help_message"] = "اگر زمینه های سفارشی مشابهی برای٪ s وجود داشته باشد ، این مقادیر به موارد اضافه می شوند در غیر این صورت ،  زمینه های سفارشی جدیدی برای٪ s ایجاد می کند و مقادیری را به آن اضافه می کند";
$lang["lead_created"] = "پیشتاز ساخته شد";
$lang["notification_lead_created"] = "پیشتاز جدیدی ساخت";
$lang["client_created_from_lead"] = "مشتری ساحته شده از پیشتاز";
$lang["notification_client_created_from_lead"] = "تبدیل پیشتاز به مشتری";
$lang["project_deadline"] = "مهلت پروژه";
$lang["task_deadline"] = "مهلت کار";
$lang["event_type"] = "نوع رویداد";
$lang["delete_estimate_form"] = "حذف فرم برآورد";
$lang["calendar_event_modified"] = "رویداد تقویم اصلاح شد";
$lang["notification_calendar_event_modified"] = "رویدادی را اصلاح کرد";

$lang["there_has_leads_with_this_status"] = "با این وضعیت پیشتازهایی وجود دارد";
$lang["lead_created_at"] = "پیشتاز ساخته شد در";
$lang["past_lead_information"] = "اطلاعات گذشته پیشتاز";
$lang["last_status"] = "آخرین وضعیت";
$lang["migrated_to_client_at"] = "به مشتری تغییر داده شد در ";
$lang["edit_estimate_form"] = "ویرایش فرم برآورد";

$lang["please_upload_a_excel_file"] = "لطفاً یک فایل اکسل بارگذاری کنید";
$lang["back"] = "بازگشت";

$lang["import_client_error_header"] = "یک سربرگ نامعتبر است. قسمت مشخص شده باید <b>%s</b>.";
$lang["import_client_error_company_name_field_required"] = "قسمت نام شرکت الزامی است";
$lang["import_client_error_contact_name"] = "برای اضافه کردن مخاطب مشتری ، نام و نام خانوادگی مخاطب لازم است";
$lang["import_client_error_contact_email"] = "ایمیل مخاطب لازم است و ایمیل باید برای اضافه کردن مخاطب منحصر به فرد باشد";
$lang["error"] = "خطا";
$lang["contact_first_name"] = "نام مخاطب";
$lang["contact_last_name"] = "نام خانوادگی مخاطب";
$lang["contact_email"] = "ایمیل مخاطب";

$lang["clone_invoice"] = "شبیه سازی فاکتور";
$lang["copy_items"] = "کپی کردن موارد";
$lang["copy_discount"] = "کپی کردن تخفیف";

$lang["clone_task"] = "شبیه سازی کار";
$lang["copy_checklist"] = "کپی کردن چک لیست";

$lang["auto_assign_estimate_request_to"] = "درخواست برآورد خودکار برای";

$lang["email_template_variable"] = "متغیر الگوی ایمیل";
$lang["example_variable_name"] = "اسم_الگوی_پیشنهادی";

$lang["imap_extension_error_help_message"] = "پسوند IMAP را در سرور خود ندارید. لطفا افزونه مورد نیار را برای این اقدام نصب کنید.";

$lang["initial_number_of_the_invoice"] = "شماره اولیه فاکتور";
$lang["the_invoices_id_must_be_larger_then_last_invoice_id"] = "شناسه فاکتورها باید بزرگتر از آخرین شناسه فاکتور باشد";

$lang["client_dashboard_help_message"] = "این داشبورد برای همه مشتری ها ثابت خواهد بود. لطفاً توجه داشته باشید که اطلاعات قابل مشاهده در این ویجت ، اطلاعات واقعی مشتری نیستند";
$lang["send_to_lead"] = "ارسال برای پیشتاز";
$lang["lead"] = "پیشتاز";
$lang["leads"] = "پیشتازها";
$lang["add_lead"] = "افزودن پیشتاز";
$lang["edit_lead"] = "ویرایش پیشتاز";
$lang["delete_lead"] = "حذف پیشتاز";
$lang["lead_details"] = "جزئیات پیشتاز";
$lang["can_access_leads_information"] = "می توان به اطلاعات پیشتاز دسترسی پیدا کرد؟";
$lang["lead_info"] = "اطلاعات پیشتاز";

$lang["send_task_reminder_on_the_day_of_deadline"] = "ارسال یادآوری کار در آخرین روز مهلت تعیین شده";
$lang["send_task_deadline_pre_reminder"] = "ارسال مهلت کار از طریق یادآور";
$lang["send_task_deadline_overdue_reminder"] = "ارسال یادآوری تأخیر مهلت کار";

$lang["project_task_deadline_reminder"] = "یادآوری مهلت کار پروژه";

$lang["project_task_deadline_pre_reminder"] = "یادآوری مهلت کار پروژه";
$lang["project_task_deadline_overdue_reminder"] = "ارسال یادآوری تأخیر مهلت کار";
$lang["project_task_reminder_on_the_day_of_deadline"] = "یادآوری کار پروژه در روز آخر مهلت تعیین شده";

$lang["notification_project_task_deadline_pre_reminder"] = "یادآور: برخی از کارها باید به زودی به اتمام برسند";
$lang["notification_project_task_deadline_overdue_reminder"] = "یادآوری: مهلت کار به تأخیر افتاده است";
$lang["notification_project_task_reminder_on_the_day_of_deadline"] = "یادآوری: برخی از کارها امروز باید تمام شوند";

$lang["mark_as_public"] = "علامت گذاری به عنوان عمومی";
$lang["note_details"] = "یادداشت جزئیات";
$lang["public_note_by"] = "یادداشت عمومی توسط";
$lang["marked_as_public"] = "علامت گذاری به عنوان عمومی";

$lang["client_can_view_activity"] = "مشتری می تواند فعالیت پروژه را مشاهده کند";

$lang["event_settings"] = "تنظیمات رویداد";
$lang["enable_google_calendar_api"] = "فعال سازی تقویم API گوگل";
$lang["google_calendar_settings"] = "تنظیمات تقویم گوگل";

$lang["your_calendar_ids"] = "شناسه های تقویم شما";
$lang["calendar_id"] = "شناسه تقویم";
$lang["now_every_user_can_integrate_with_their_google_calendar"] = "اکنون هر کاربری می تواند با تقویم گوگل خود یکپارچه شود";
$lang["calendar_ids_help_message"] = "شما همیشه رویدادهای تقویم خود را دریافت خواهید کرد. این مربوط به تقویم های ویژه دیگر است (مانند تقویم تعطیلات).";

$lang["google_client_id"] = "شناسه مشتری";
$lang["google_client_secret"] = "رمز مشتری";
$lang["integrate_with_google_calendar"] = "ادغام با تقویم گوگل";
$lang["google_calendar_event"] = "رویداد تقویم گوگل";

$lang["mark_as_public_help_message"] = "شما نمی توانید دوباره این یادداشت را به صورت خصوصی انجام دهید";

$lang["google_calendar_help_message"] = "رویدادهای تقویم گوگل خود را با اجرای کورن جاب دریافت خواهید کرد. و هرگونه افزودن / تغییر در رویدادهای محلی شما ، تقویم گوگل شما را فوراً تحت تأثیر قرار می دهد";

